package com.example.solid_design.Interface_Segregation;

public class BasicScanner implements Scanner {

  @Override
  public void scan() {
    System.out.println("BasicScanner is scanning");
  }
}
