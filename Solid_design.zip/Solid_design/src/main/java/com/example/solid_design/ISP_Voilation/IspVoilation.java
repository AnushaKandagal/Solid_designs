package com.example.solid_design.ISP_Voilation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class IspVoilation {

  OldPrinter printer;

  @Autowired
  IspVoilation(OldPrinter printer) {}

  public void work() {
    printer.print();
    printer.scan();
    printer.fax();
  }

}
