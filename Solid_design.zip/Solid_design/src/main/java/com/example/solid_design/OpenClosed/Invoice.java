package com.example.solid_design.OpenClosed;


class Invoice {
  private DiscountStrategy discountStrategy;

  public Invoice(DiscountStrategy discountStrategy) {
    this.discountStrategy = discountStrategy;
  }

  public double getFinalAmount(double amount) {
    return discountStrategy.applyDiscount(amount);
  }
}
