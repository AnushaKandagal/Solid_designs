package com.example.solid_design.Liskov_substitution;

import org.springframework.stereotype.Component;

@Component
public class Penguin2 implements Non_flying_Bird{

  @Override
  public void eat() {
    System.out.println("Penguin2 is eating");
  }
}
