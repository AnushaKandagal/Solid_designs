package com.example.solid_design.DependencyInversion;

public interface MessageSender {
  public void sendMessage(String message);
}
