package com.example.solid_design.Interface_Segregation;

public class BasicPrinter implements Printer {

  @Override
  public void print() {
    System.out.println("Basic printer is printing");
  }
}
