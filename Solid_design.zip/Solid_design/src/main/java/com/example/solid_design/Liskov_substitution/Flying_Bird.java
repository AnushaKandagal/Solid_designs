package com.example.solid_design.Liskov_substitution;

public interface Flying_Bird extends Bird {
  public void fly();
}
