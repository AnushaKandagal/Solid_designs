package com.example.solid_design.LSP_Voilation;

import org.springframework.stereotype.Component;

@Component
public class Penguin extends Bird_base{
    public Penguin(){

    }

    @Override
    public void fly(){
      throw new UnsupportedOperationException("UnsupportedOperationException : Penguin cannot fly");
    }
}
