package com.example.solid_design.Liskov_substitution;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Liskov_substitution {
  public Crow crow;
  public Penguin2 penguin;

  @Autowired
  Liskov_substitution(Crow crow, Penguin2 penguin) {
    this.crow = crow;
    this.penguin = penguin;
  }

  public void makeThemFly(Flying_Bird bird){
    bird.fly();
    //penguin cannot be passed
  }

  public void makeThemEat(Bird bird){
    bird.eat();
  }
}
