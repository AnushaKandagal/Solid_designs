package com.example.solid_design.LSP_Voilation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Lsp_voilation {
  private Sparrow sparrow;
  private Penguin penguin;

  @Autowired
  public Lsp_voilation(Sparrow sparrow, Penguin penguin) {
    this.sparrow = sparrow;
    this.penguin = penguin;
  }

  public void make_them_fly(Bird_base bird) {
    bird.fly();
  }

}
