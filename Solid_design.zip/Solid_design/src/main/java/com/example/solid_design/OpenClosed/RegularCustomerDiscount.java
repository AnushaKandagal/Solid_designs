package com.example.solid_design.OpenClosed;


// Concrete strategies
class RegularCustomerDiscount implements DiscountStrategy {
  public double applyDiscount(double amount) {
    return amount * 0.90; // 10% discount
  }
}

