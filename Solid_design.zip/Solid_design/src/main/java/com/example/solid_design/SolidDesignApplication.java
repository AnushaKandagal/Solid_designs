package com.example.solid_design;

import com.example.solid_design.DependencyInversion.NotificationApp;
import com.example.solid_design.ISP_Voilation.IspVoilation;
import com.example.solid_design.Interface_Segregation.PrinterFactory;
import com.example.solid_design.LSP_Voilation.Lsp_voilation;
import com.example.solid_design.LSP_Voilation.Penguin;
import com.example.solid_design.LSP_Voilation.Sparrow;
import com.example.solid_design.Liskov_substitution.Crow;
import com.example.solid_design.Liskov_substitution.Liskov_substitution;
import com.example.solid_design.Liskov_substitution.Penguin2;
import com.example.solid_design.OpenClosed.BillingSystem;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class SolidDesignApplication {

  public static void main(String[] args) {
    ApplicationContext context = SpringApplication.run(SolidDesignApplication.class, args);
    System.out.println("Trying lsp violation...");
    Lsp_voilation lsp_voilation = context.getBean(Lsp_voilation.class);

    try{
      lsp_voilation.make_them_fly(new Sparrow());
      lsp_voilation.make_them_fly(new Penguin());
    } catch (Exception e){
      System.out.println(e.getMessage());
    }

    System.out.println("Liskov substitution...");
    Liskov_substitution liskov_substitution = context.getBean(Liskov_substitution.class);
    try{
      liskov_substitution.makeThemFly(new Crow());
      //liskov_substitution.makeThemFly(new Penguin2()); compile error
      liskov_substitution.makeThemEat(new Crow());
      liskov_substitution.makeThemEat(new Penguin2());
    }catch (Exception e){
      System.out.println(e.getMessage());
    }

    System.out.println("Trying  isp violation...");
    IspVoilation ispVoilation = context.getBean(IspVoilation.class);
    try{
      ispVoilation.work();
    }catch (Exception e){
      System.out.println(e.getMessage());
    }

    System.out.println("Trying  Interface segregation principle...");
    PrinterFactory printerFactory = context.getBean(PrinterFactory.class);
    try{
      printerFactory.work();
    }catch (Exception e){
      System.out.println(e.getMessage());
    }

    System.out.println("Open closed principle...");
    BillingSystem billingSystem = context.getBean(BillingSystem.class);
    try{
      billingSystem.bill();
    }catch (Exception e){
      System.out.println(e.getMessage());
    }

    System.out.println("Dependency Inversion principle.....");
    NotificationApp notificationApp = context.getBean(NotificationApp.class);
    try {
      notificationApp.sendNotifications();
    }catch (Exception e){
      System.out.println(e.getMessage());
    }

  }

}
