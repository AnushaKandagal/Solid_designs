package com.example.solid_design.DependencyInversion;

import org.springframework.stereotype.Component;

@Component
public class SMSSender implements MessageSender {

  @Override
  public void sendMessage(String message) {
    System.out.println("SMS sender: "+message);
  }
}
