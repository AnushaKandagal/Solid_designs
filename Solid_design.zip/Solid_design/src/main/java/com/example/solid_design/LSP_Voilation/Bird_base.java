package com.example.solid_design.LSP_Voilation;

import org.springframework.stereotype.Component;

// base class
@Component
public class Bird_base {
  public Bird_base() {}

  public void fly() {
    System.out.println("Bird fly");
  }
}
