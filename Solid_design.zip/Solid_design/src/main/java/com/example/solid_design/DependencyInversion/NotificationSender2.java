package com.example.solid_design.DependencyInversion;

public class NotificationSender2 {
  private final MessageSender mSender;

  NotificationSender2(MessageSender sender) {
    this.mSender = sender;
  }

  public void sendNotification(String message) {
    mSender.sendMessage(message);
  }
}
