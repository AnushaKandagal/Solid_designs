package com.example.solid_design.DIP_Voilation;

import org.springframework.stereotype.Component;

@Component
public class EmailSender {

  public void sendEmail(String message) {
    System.out.println("Sending email: " + message);
  }

}
