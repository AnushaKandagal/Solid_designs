package com.example.solid_design.OpenClosed;


class FestiveDiscount implements DiscountStrategy {
  public double applyDiscount(double amount) {
    return amount * 0.70; // 30% discount
  }
}

