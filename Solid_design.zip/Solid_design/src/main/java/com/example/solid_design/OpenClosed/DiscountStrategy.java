package com.example.solid_design.OpenClosed;

public interface DiscountStrategy {
  double applyDiscount(double amount);
}
