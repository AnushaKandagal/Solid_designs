package com.example.solid_design.Interface_Segregation;

public interface Printer {
  public void print();
}
