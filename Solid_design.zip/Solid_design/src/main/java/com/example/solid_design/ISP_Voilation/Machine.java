package com.example.solid_design.ISP_Voilation;

public interface Machine {

  void print();
  void scan();
  void fax();

}
