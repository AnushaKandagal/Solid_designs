package com.example.solid_design.DIP_Voilation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class NotificationSender {
  EmailSender emailSender; // Violation of DIP (dependency Inversion)
  // In future if we want to include SMS , we need to modify this class, refer DIP implementation.

  @Autowired
  NotificationSender(EmailSender emailSender) {
    this.emailSender = emailSender;
  }
  public void sendNotification(String msg) {
    emailSender.sendEmail(msg);
  }
}
