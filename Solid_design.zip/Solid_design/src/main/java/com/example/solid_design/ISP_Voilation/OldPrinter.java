package com.example.solid_design.ISP_Voilation;

import org.springframework.stereotype.Component;

@Component
public class OldPrinter implements Machine {

  // forced to implement all functionalities
  @Override
  public void print() {
    System.out.println("Old Printer is printing");
  }

  public void scan() {
    throw new UnsupportedOperationException("Scan not supported");
  }

  public void fax() {
    throw new UnsupportedOperationException("Fax not supported");
  }

}
