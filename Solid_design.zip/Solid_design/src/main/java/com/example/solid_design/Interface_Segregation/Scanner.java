package com.example.solid_design.Interface_Segregation;

public interface Scanner {
    public void scan();
}
