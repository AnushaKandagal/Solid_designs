package com.example.solid_design.LSP_Voilation;

import org.springframework.stereotype.Component;

@Component
public class Sparrow extends Bird_base{
  public Sparrow(){
    // TODO document why this constructor is empty
  }

  @Override
  public void fly(){
    System.out.println("Sparrow flies");
  }
}
