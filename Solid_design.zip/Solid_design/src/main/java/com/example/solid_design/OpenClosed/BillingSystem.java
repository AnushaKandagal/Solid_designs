package com.example.solid_design.OpenClosed;

import org.springframework.stereotype.Component;

@Component
public class BillingSystem {
  /*
  Scenario: Invoice Discount Calculation
You’re building a billing system. Initially, you have a class that calculates discounts for regular customers. Later, you need to support premium customers, festive discounts, etc.

If you keep modifying the same class every time a new discount type is added, you violate OCP.

Instead, you should design the system so that new discount types can be added without modifying existing code.
   */

  public static void bill() {
    Invoice regularInvoice = new Invoice(new RegularCustomerDiscount());
    Invoice premiumInvoice = new Invoice(new PremiumCustomerDiscount());
    Invoice festiveInvoice = new Invoice(new FestiveDiscount());

    System.out.println("Regular Customer: " + regularInvoice.getFinalAmount(1000));
    System.out.println("Premium Customer: " + premiumInvoice.getFinalAmount(1000));
    System.out.println("Festive Offer: " + festiveInvoice.getFinalAmount(1000));
  }

}
