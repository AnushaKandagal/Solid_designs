package com.example.solid_design.DependencyInversion;

import org.springframework.stereotype.Component;

@Component
public class NotificationApp {
  public void sendNotifications() {
    NotificationSender2 emailNotificationSender = new NotificationSender2(new EmailSender2());
    emailNotificationSender.sendNotification("email notification....");

    NotificationSender2 smsNotificationSender = new NotificationSender2(new SMSSender());
    smsNotificationSender.sendNotification("sms notification....");
  }
}
