package com.example.solid_design.Interface_Segregation;

public class AllRounderPrinter implements Printer, Scanner, Fax {

  @Override
  public void fax() {
    System.out.println(" AllRounderPrinter fax");
  }

  @Override
  public void print() {
    System.out.println(" AllRounderPrinter print");
  }

  @Override
  public void scan() {
    System.out.println(" AllRounderPrinter scan");
  }
}
