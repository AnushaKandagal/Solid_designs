package com.example.solid_design.Interface_Segregation;

public interface Fax {
    public void fax();
}
