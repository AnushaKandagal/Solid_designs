package com.example.solid_design.Interface_Segregation;

import org.springframework.stereotype.Component;

@Component
public class PrinterFactory {
  public PrinterFactory() {

  }

  public void work() {
    Printer basicPrinter = new BasicPrinter();
    Scanner scannerDevice = new BasicScanner();
    AllRounderPrinter arp = new AllRounderPrinter();

    basicPrinter.print();       // ✅ Works
    scannerDevice.scan();       // ✅ Works
    arp.print();                // ✅ Works
    arp.scan();                 // ✅ Works
    arp.fax();                  // ✅ Works
  }
}

