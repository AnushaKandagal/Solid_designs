package com.example.solid_design.Liskov_substitution;

public interface Non_flying_Bird extends Bird {

}
