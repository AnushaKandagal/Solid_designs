package com.example.solid_design.OpenClosed;


class PremiumCustomerDiscount implements DiscountStrategy {
  public double applyDiscount(double amount) {
    return amount * 0.80; // 20% discount
  }
}

