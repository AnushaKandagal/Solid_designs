package com.example.solid_design.Liskov_substitution;

public interface Bird {
  public void eat();
}
