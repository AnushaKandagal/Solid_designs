package com.example.solid_design.Liskov_substitution;

import org.springframework.stereotype.Component;

@Component
public class Crow implements Flying_Bird{
  @Override
  public void fly() {
    System.out.println("Crow flying");
  }

  @Override
  public void eat() {
    System.out.println("Crow eating");
  }
}
