package com.example.solid_design;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SolidDesignApplicationTests {

  @Test
  void contextLoads() {
  }

}
